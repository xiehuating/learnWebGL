These are the project files for the Eat3D tutorial MatCaps in Blender.


Thank You for Your Purchase,
Eat3D


*Notice:
Eat 3D is not responsible for any damage caused by the files you downloaded or the files on the DVD. Please back up your work and exercise caution when going through our files. As described in the videos, be advised that many of our project files are very resource intensive so use at your own risk. 

Copyright 2010 Eat 3d, LLC All Rights Reserved. These files are for personal and educational use only. Please do not redistribute them to anyone and please report any abuse to abuse@eat3d.com. Thanks for your purchase and support.